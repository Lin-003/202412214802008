"use strict";

const { vec3 } = glMatrix;

var canvas;
var gl;

var points = [];

/** Parameters */
var numTimesToSubdivide = 0;
var theta=60;
var twist=false;

var radius=1.0;

// runtime globals for dynamic behavior
var program = null;
var vertexBuffer = null;
var rotationEnabled = false;
var rotationSpeed = 30; // degrees per second
var globalAngle = 0; // degrees
var lastTime = 0;

// scaling globals
var scaleEnabled = false;
var scaleFactor = 1.0; // current scale multiplier
var scaleSpeed = 0.0; // multiplier change per second (units: scale per second)
var globalScale = 1.0; // current global scale

// moving (translation) globals
var moveEnabled = false;
var moveOffsetX = 0.0;
var moveOffsetY = 0.0;
var moveSpeedX = 0.0; // units per second
var moveSpeedY = 0.0; // units per second

// distance-based rotation controls
var distanceBased = false;
var distanceFactor = 0.5;

// store base geometry (without global rotation) so we can reapply rotation each frame
var basePoints = [];

window.onload = function initTriangles(){
	canvas = document.getElementById( "gl-canvas" );

	gl = canvas.getContext("webgl2");
	if( !gl ){
		alert( "WebGL isn't available" );
		return;
	}

	// configure webgl
	gl.viewport( 0, 0, canvas.width, canvas.height );
	gl.clearColor( 1.0, 1.0, 1.0, 1.0 );

	// load shaders and initialise attribute buffers
	program = initShaders( gl, "vertex-shader", "fragment-shader" );
	gl.useProgram( program );

	// create buffer once
	vertexBuffer = gl.createBuffer();

	// setup controls
	setupControls();

	// initial computation and start render loop
	updateBaseGeometry(numTimesToSubdivide);
	lastTime = performance.now();
	requestAnimationFrame( animate );
};

function tessellaTriangle( a, b, c ){
    //var k;
    var zerovec3 = vec3.create();
    vec3.zero( zerovec3 );
    var radian = theta * Math.PI / 180.0;
    
    var a_new = vec3.create();
    var b_new = vec3.create();
    var c_new = vec3.create();

    if( twist == false ){
        vec3.rotateZ( a_new, a, zerovec3, radian );
        vec3.rotateZ( b_new, b, zerovec3, radian );
        vec3.rotateZ( c_new, c, zerovec3, radian );
        
        points.push( a_new[0], a_new[1], a_new[2] );
        points.push( b_new[0], b_new[1], b_new[2] );
        points.push( b_new[0], b_new[1], b_new[2] );
        points.push( c_new[0], c_new[1], c_new[2] );
        points.push( c_new[0], c_new[1], c_new[2] );
        points.push( a_new[0], a_new[1], a_new[2] );
    }else{
        var d_a = Math.sqrt( a[0] * a[0] + a[1] * a[1] );
        var d_b = Math.sqrt( b[0] * b[0] + b[1] * b[1] );
        var d_c = Math.sqrt( c[0] * c[0] + c[1] * c[1] );

        vec3.set( a_new, a[0] * Math.cos(d_a * radian) - a[1] * Math.sin( d_a * radian ), 
            a[0] * Math.sin( d_a * radian ) + a[1] * Math.cos( d_a * radian ), 0 );
        vec3.set(b_new, b[0] * Math.cos(d_b * radian) - b[1] * Math.sin(d_b * radian),
            b[0] * Math.sin(d_b * radian) + b[1] * Math.cos(d_b * radian), 0);
        vec3.set(c_new, c[0] * Math.cos(d_c * radian) - c[1] * Math.sin(d_c * radian),
            c[0] * Math.sin(d_c * radian) + c[1] * Math.cos(d_c * radian), 0);
        
        points.push(a_new[0], a_new[1], a_new[2]);
        points.push(b_new[0], b_new[1], b_new[2]);
        points.push(b_new[0], b_new[1], b_new[2]);
        points.push(c_new[0], c_new[1], c_new[2]);
        points.push(c_new[0], c_new[1], c_new[2]);
        points.push(a_new[0], a_new[1], a_new[2]);
    
    }
}

function divideTriangle( a, b, c, count ){
	// check for end of recursion
	if( count == 0 ){
		tessellaTriangle( a, b, c );
	}else{
		var ab = vec3.create();
		vec3.lerp( ab, a, b, 0.5 );
		var bc = vec3.create();
		vec3.lerp( bc, b, c, 0.5 );
		var ca = vec3.create();
		vec3.lerp( ca, c, a, 0.5 );

		// three new triangles
		divideTriangle( a, ab, ca, count-1 );
		divideTriangle( ab, b, bc, count-1 );
        divideTriangle( ca, bc, c, count-1 );
        divideTriangle( ab, bc, ca, count-1 );
	}
}

function renderTriangles(){
	gl.clear( gl.COLOR_BUFFER_BIT );
	gl.drawArrays( gl.LINES, 0, points.length/3 );
}

function setupControls(){
	var slider = document.getElementById('subdivSlider');
	var number = document.getElementById('subdivNumber');
	var label = document.getElementById('subdivLabel');
	var rotateToggle = document.getElementById('rotateToggle');
	var rotateSpeedInput = document.getElementById('rotateSpeed');
	var rotateSpeedLabel = document.getElementById('rotateSpeedLabel');

	// scaling controls
	var scaleToggle = document.getElementById('scaleToggle');
	var scaleFactorInput = document.getElementById('scaleFactor');
	var scaleNumber = document.getElementById('scaleNumber');
	var scaleFactorLabel = document.getElementById('scaleFactorLabel');
	var scaleSpeedInput = document.getElementById('scaleSpeed');
	var scaleSpeedLabel = document.getElementById('scaleSpeedLabel');
	var resetScaleBtn = document.getElementById('resetScale');

	// moving (translation) controls
	var moveToggle = document.getElementById('movedistance');
	var moveOffsetXInput = document.getElementById('moveOffsetX');
	var moveOffsetXNumber = document.getElementById('moveOffsetXNumber');
	var moveOffsetXLabel = document.getElementById('moveOffsetXLabel');
	var moveOffsetYInput = document.getElementById('moveOffsetY');
	var moveOffsetYNumber = document.getElementById('moveOffsetYNumber');
	var moveOffsetYLabel = document.getElementById('moveOffsetYLabel');
	var moveSpeedXInput = document.getElementById('moveSpeedX');
	var moveSpeedXLabel = document.getElementById('moveSpeedXLabel');
	var moveSpeedYInput = document.getElementById('moveSpeedY');
	var moveSpeedYLabel = document.getElementById('moveSpeedYLabel');
	var resetMoveBtn = document.getElementById('resetmove');

	function syncAndUpdate(value){
		value = Math.max(0, Math.min(7, parseInt(value) || 0));
		slider.value = value;
		number.value = value;
		label.textContent = '(' + value + ')';
		updateBaseGeometry(value);
	}

	slider.addEventListener('input', function(e){ syncAndUpdate(e.target.value); });
	number.addEventListener('change', function(e){ syncAndUpdate(e.target.value); });

	rotateToggle.addEventListener('change', function(e){ rotationEnabled = e.target.checked; });
	rotateSpeedInput.addEventListener('input', function(e){
		rotationSpeed = parseInt(e.target.value) || 0;
		rotateSpeedLabel.textContent = rotationSpeed + '°/s';
	});

	// scaling bindings
	if(scaleToggle){
		scaleToggle.addEventListener('change', function(e){ scaleEnabled = e.target.checked; });
	}
	if(scaleFactorInput && scaleNumber){
		function syncScale(value){
			var v = Math.max(0.1, Math.min(3.0, parseFloat(value) || 1.0));
			scaleFactorInput.value = v;
			scaleNumber.value = v;
			scaleFactorLabel.textContent = v.toFixed(2) + 'x';
			scaleFactor = v;
		}
		scaleFactorInput.addEventListener('input', function(e){ syncScale(e.target.value); });
		scaleNumber.addEventListener('change', function(e){ syncScale(e.target.value); updateBaseGeometry(numTimesToSubdivide); });
	}
	if(scaleSpeedInput){
		scaleSpeedInput.addEventListener('input', function(e){ scaleSpeed = parseFloat(e.target.value) || 0.0; scaleSpeedLabel.textContent = scaleSpeed.toFixed(1) + 'x/s'; });
	}
	if(resetScaleBtn){
		resetScaleBtn.addEventListener('click', function(){ globalScale = 1.0; scaleFactor = 1.0; if(scaleFactorInput) scaleFactorInput.value = 1.0; if(scaleNumber) scaleNumber.value = 1.0; if(scaleFactorLabel) scaleFactorLabel.textContent = '1.00x'; applyGlobalRotationAndUpload(globalAngle); renderTriangles(); });
	}

	// moving bindings
	if(moveToggle){
		moveToggle.addEventListener('change', function(e){ moveEnabled = e.target.checked; });
	}
	// X offset bindings
	if(moveOffsetXInput && moveOffsetXNumber){
		function syncMoveX(v){
			var val = Math.max(-2.0, Math.min(2.0, parseFloat(v) || 0.0));
			moveOffsetXInput.value = val;
			moveOffsetXNumber.value = val;
			moveOffsetXLabel.textContent = val.toFixed(2);
			moveOffsetX = val;
		}
		moveOffsetXInput.addEventListener('input', function(e){ syncMoveX(e.target.value); });
		moveOffsetXNumber.addEventListener('change', function(e){ syncMoveX(e.target.value); });
	}
	// Y offset bindings
	if(moveOffsetYInput && moveOffsetYNumber){
		function syncMoveY(v){
			var val = Math.max(-2.0, Math.min(2.0, parseFloat(v) || 0.0));
			moveOffsetYInput.value = val;
			moveOffsetYNumber.value = val;
			moveOffsetYLabel.textContent = val.toFixed(2);
			moveOffsetY = val;
		}
		moveOffsetYInput.addEventListener('input', function(e){ syncMoveY(e.target.value); });
		moveOffsetYNumber.addEventListener('change', function(e){ syncMoveY(e.target.value); });
	}
	// speed bindings
	if(moveSpeedXInput){
		moveSpeedXInput.addEventListener('input', function(e){ moveSpeedX = parseFloat(e.target.value) || 0.0; moveSpeedXLabel.textContent = moveSpeedX.toFixed(2) + '/s'; });
	}
	if(moveSpeedYInput){
		moveSpeedYInput.addEventListener('input', function(e){ moveSpeedY = parseFloat(e.target.value) || 0.0; moveSpeedYLabel.textContent = moveSpeedY.toFixed(2) + '/s'; });
	}
	if(resetMoveBtn){
		resetMoveBtn.addEventListener('click', function(){ moveOffsetX = 0.0; moveOffsetY = 0.0; moveSpeedX = 0.0; moveSpeedY = 0.0; if(moveOffsetXInput) moveOffsetXInput.value = 0.0; if(moveOffsetXNumber) moveOffsetXNumber.value = 0.0; if(moveOffsetXLabel) moveOffsetXLabel.textContent = '0.00'; if(moveOffsetYInput) moveOffsetYInput.value = 0.0; if(moveOffsetYNumber) moveOffsetYNumber.value = 0.0; if(moveOffsetYLabel) moveOffsetYLabel.textContent = '0.00'; if(moveSpeedXInput) moveSpeedXInput.value = 0.0; if(moveSpeedXLabel) moveSpeedXLabel.textContent = '0.00/s'; if(moveSpeedYInput) moveSpeedYInput.value = 0.0; if(moveSpeedYLabel) moveSpeedYLabel.textContent = '0.00/s'; applyGlobalRotationAndUpload(globalAngle); renderTriangles(); });
	}

	// optional distance-based controls if present in HTML
	try{
		var distanceCheckbox = document.getElementById('distanceBased');
		var distanceFactorInput = document.getElementById('distanceFactor');
		var distanceFactorLabel = document.getElementById('distanceFactorLabel');
		if(distanceCheckbox){
			distanceCheckbox.addEventListener('change', function(e){ distanceBased = e.target.checked; });
		}
		if(distanceFactorInput){
			distanceFactorInput.addEventListener('input', function(e){ distanceFactor = parseFloat(e.target.value) || 0; if(distanceFactorLabel) distanceFactorLabel.textContent = distanceFactor; });
		}
	}catch(e){ /* ignore if elements missing */ }
	// fixed-step rotation controls
	var stepInput = document.getElementById('stepAngle');
	var rotateLeftBtn = document.getElementById('rotateLeft');
	var rotateRightBtn = document.getElementById('rotateRight');
	var resetBtn = document.getElementById('resetAngle');

	function stepRotate(direction){
		var step = parseFloat(stepInput.value) || 0;
		globalAngle = (globalAngle + direction * step) % 360;
		// immediately apply rotation and upload current geometry
		applyGlobalRotationAndUpload(globalAngle);
		renderTriangles();
	}

	rotateLeftBtn.addEventListener('click', function(){ stepRotate(-1); });
	rotateRightBtn.addEventListener('click', function(){ stepRotate(1); });
	resetBtn.addEventListener('click', function(){ globalAngle = 0; applyGlobalRotationAndUpload(globalAngle); renderTriangles(); });
}

function updateBaseGeometry(subdivision){
	numTimesToSubdivide = subdivision;
	basePoints.length = 0;
	// compute base geometry into basePoints
	var vertices = [
		radius * Math.cos(90 * Math.PI / 180.0), radius * Math.sin(90 * Math.PI / 180.0),  0,
		radius * Math.cos(210 * Math.PI / 180.0), radius * Math.sin(210 * Math.PI / 180.0),  0,
		radius * Math.cos(-30 * Math.PI / 180.0), radius * Math.sin(-30 * Math.PI / 180.0),  0
	];

	var u = vec3.fromValues( vertices[0], vertices[1], vertices[2] );
	var v = vec3.fromValues( vertices[3], vertices[4], vertices[5] );
	var w = vec3.fromValues( vertices[6], vertices[7], vertices[8] );

	// temporarily use points array to collect, then copy to basePoints
	points.length = 0;
	divideTriangle( u, v, w, numTimesToSubdivide );
	// copy to basePoints
	for(var i=0;i<points.length;i++) basePoints[i]=points[i];
}

function applyGlobalRotationAndUpload(angleDegrees){
	// angleDegrees is the base angle; if distanceBased is true, per-vertex angle scales with distance
	points.length = 0;

	// determine current scale to apply
	var currentScale = 1.0;
	if(scaleEnabled){
		// combine base scaleFactor with any animated globalScale
		currentScale = scaleFactor * globalScale;
	}

	// translation offsets to apply (additive). Only apply if enabled.
	var tx = 0.0, ty = 0.0;
	if(moveEnabled){
		tx = moveOffsetX;
		ty = moveOffsetY;
	}

	
	if(!distanceBased){
		var rad = angleDegrees * Math.PI / 180.0;
		var cos = Math.cos(rad), sin = Math.sin(rad);
		for(var i=0;i<basePoints.length;i+=3){
			var x = basePoints[i] * currentScale + tx, y = basePoints[i+1] * currentScale + ty, z = basePoints[i+2] * currentScale;
			var rx = x * cos - y * sin;
			var ry = x * sin + y * cos;
			points.push(rx, ry, z);
		}
	} else {
		// Vortex (polar) transform: for each point (r,phi) -> (r, phi + k*r)
		// k is scale factor derived from angleDegrees and distanceFactor
		var k = angleDegrees * distanceFactor * Math.PI / 180.0; // radians per unit distance
		for(var i=0;i<basePoints.length;i+=3){
			var x = basePoints[i] * currentScale, y = basePoints[i+1] * currentScale, z = basePoints[i+2] * currentScale;
			x = x + tx;
			y = y + ty;
			var r = Math.sqrt(x*x + y*y);
			var phi = Math.atan2(y, x);
			var phi2 = phi + k * r; // swirl proportional to radius
			var rx = r * Math.cos(phi2);
			var ry = r * Math.sin(phi2);
			points.push(rx, ry, z);
		}
	}

	// upload
	gl.bindBuffer( gl.ARRAY_BUFFER, vertexBuffer );
	gl.bufferData( gl.ARRAY_BUFFER, new Float32Array( points ), gl.STATIC_DRAW );

	var vPosition = gl.getAttribLocation( program, "vPosition" );
	gl.vertexAttribPointer( vPosition, 3, gl.FLOAT, false, 0, 0 );
	gl.enableVertexAttribArray( vPosition );
}

function animate(now){
	// now is DOMHighResTimeStamp in ms
	var delta = (now - lastTime) / 1000.0; // seconds
	lastTime = now;

	if(rotationEnabled){
		globalAngle = (globalAngle + rotationSpeed * delta) % 360;
	}

	// update scaling animation if enabled
	if(scaleEnabled && Math.abs(scaleSpeed) > 1e-6){
		// scaleSpeed is change in scale per second
		globalScale = globalScale + scaleSpeed * delta;
		// clamp to reasonable range to avoid collapse
		globalScale = Math.max(0.01, Math.min(100.0, globalScale));
	}

	// update moving animation if enabled
	if(moveEnabled && (Math.abs(moveSpeedX) > 1e-6 || Math.abs(moveSpeedY) > 1e-6)){
		moveOffsetX = moveOffsetX + moveSpeedX * delta;
		moveOffsetY = moveOffsetY + moveSpeedY * delta;
		// clamp offsets to avoid runaway
		moveOffsetX = Math.max(-10.0, Math.min(10.0, moveOffsetX));
		moveOffsetY = Math.max(-10.0, Math.min(10.0, moveOffsetY));
	}

	applyGlobalRotationAndUpload(globalAngle);
	renderTriangles();

	requestAnimationFrame( animate );
}